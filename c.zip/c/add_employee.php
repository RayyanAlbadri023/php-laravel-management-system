<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO employees (full_name, email, phone, department, position, salary, hire_date) VALUES (?, ?, ?, ?, ?, ?, CURDATE())");
    $stmt->execute([
        trim($_POST['full_name']),
        trim($_POST['email']),
        trim($_POST['phone']),
        trim($_POST['department']),
        trim($_POST['position']),
        !empty($_POST['salary']) ? $_POST['salary'] : null
    ]);
}

header('Location: home.php?added=1');
exit;
