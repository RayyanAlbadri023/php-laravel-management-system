<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$pdo = getDBConnection();

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header('Location: home.php');
    exit;
}

$employees = $pdo->query("SELECT * FROM employees ORDER BY created_at DESC")->fetchAll();
$total  = count($employees);
$active = count(array_filter($employees, fn($e) => $e['status'] === 'active'));
$depts  = count(array_unique(array_column($employees, 'department')));
$avgSalary = $total > 0 ? array_sum(array_column($employees, 'salary')) / $total : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee System</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: linear-gradient(135deg, #f5f7f5 0%, #c8d9c6 100%);
            min-height: 100vh;
            color: #1a1a1a;
        }

        /* ── PAGE WRAPPER ── */
        .page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px 16px;
            gap: 20px;
        }

        /* ── HEADER ── */
        .header {
            width: 100%;
            max-width: 960px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(24,56,18,0.2);
            border-radius: 20px;
            padding: 14px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
        }

        .header-left a {
            display: inline-block;
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 600;
            color: #fff;
            border-radius: 50px;
            background: linear-gradient(135deg, #183812, #3a7a30);
            text-decoration: none;
            transition: opacity 0.15s;
        }
        .header-left a:hover { opacity: 0.85; }

        .header-center { text-align: center; }
        .header-center h1 {
            font-size: clamp(17px, 4vw, 22px);
            font-weight: 800;
            color: #183812;
            letter-spacing: -0.4px;
        }
        .header-center p { font-size: 13px; color: #555; margin-top: 2px; }
        .header-center p span { font-weight: 700; color: #1a1a1a; }

        .header-right {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-logout {
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 600;
            color: #fff;
            border-radius: 50px;
            background: linear-gradient(135deg, #e53e3e, #fc8181);
            border: none;
            cursor: pointer;
            text-decoration: none;
            transition: opacity 0.15s;
        }
        .btn-logout:hover { opacity: 0.85; }

        /* ── STATS ── */
        .stats {
            width: 100%;
            max-width: 960px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
        }

        .stat-card {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(24,56,18,0.2);
            border-radius: 20px;
            padding: 20px 22px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: transform 0.15s, box-shadow 0.15s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(24,56,18,0.14);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
            background: linear-gradient(135deg, #183812, #3a7a30);
            box-shadow: 0 4px 14px rgba(24,56,18,0.3);
        }

        .stat-info .num {
            font-size: 28px;
            font-weight: 800;
            color: #183812;
            line-height: 1;
            letter-spacing: -0.5px;
        }

        .stat-info .lbl {
            font-size: 12px;
            color: #777;
            margin-top: 3px;
            font-weight: 500;
        }

        /* ── ADD FORM SECTION ── */
        .section {
            width: 100%;
            max-width: 960px;
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(24,56,18,0.2);
            border-radius: 20px;
            padding: 22px 24px;
        }

        .section-title {
            font-size: 15px;
            font-weight: 700;
            color: #183812;
            margin-bottom: 16px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 10px;
        }

        input, select {
            width: 100%;
            padding: 10px 13px;
            border: 1.5px solid rgba(24,56,18,0.2);
            border-radius: 10px;
            font-size: 13px;
            color: #1a1a1a;
            outline: none;
            transition: border 0.15s;
            background: #fff;
            font-family: 'DM Sans', sans-serif;
        }

        input:focus, select:focus { border-color: #183812; }

        .btn-add {
            background: linear-gradient(135deg, #183812, #3a7a30);
            color: #fff;
            border: none;
            padding: 10px 26px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 12px;
            transition: opacity 0.15s;
            font-family: 'DM Sans', sans-serif;
        }

        .btn-add:hover { opacity: 0.85; }

        .alert-success {
            background: rgba(24,56,18,0.08);
            color: #183812;
            border: 1px solid rgba(24,56,18,0.2);
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 14px;
            font-size: 13px;
            font-weight: 600;
        }

        /* ── TABLE ── */
        .table-scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; }

        table { width: 100%; border-collapse: collapse; min-width: 520px; }

        thead tr { background: rgba(24,56,18,0.06); }

        th {
            padding: 11px 16px;
            text-align: left;
            font-size: 11px;
            font-weight: 700;
            color: #183812;
            white-space: nowrap;
            text-transform: uppercase;
            letter-spacing: 0.6px;
            border-bottom: 1px solid rgba(24,56,18,0.1);
        }

        td {
            padding: 12px 16px;
            font-size: 13px;
            border-bottom: 1px solid rgba(24,56,18,0.06);
            color: #1a1a1a;
        }

        tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: rgba(24,56,18,0.03); }

        .badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .badge-active   { background: #d1fae5; color: #065f46; }
        .badge-inactive { background: #fee2e2; color: #991b1b; }

        .dept-tag {
            background: rgba(24,56,18,0.1);
            color: #183812;
            padding: 3px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
        }

        .delete-btn {
            color: #ccc;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.15s;
        }
        .delete-btn:hover { color: #e53e3e; }

        .empty {
            text-align: center;
            padding: 40px;
            color: #aaa;
            font-size: 14px;
        }

        /* ── ACTION BUTTONS ── */
        .action-buttons {
            width: 100%;
            max-width: 960px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }

        .action-btn {
            padding: 10px 22px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
            color: #fff;
            background: linear-gradient(135deg, #183812, #3a7a30);
            border: none;
            cursor: pointer;
            text-decoration: none;
            transition: opacity 0.15s, transform 0.15s;
            font-family: 'DM Sans', sans-serif;
        }
        .action-btn:hover { opacity: 0.85; transform: translateY(-1px); }

        @media (max-width: 600px) {
            .header { padding: 12px 14px; }
            .header-center h1 { font-size: 16px; }
        }
    </style>
</head>
<body>
<div class="page">

    <!-- HEADER -->
    <div class="header">
        <div class="header-left">
            <a href="index.php"> Home</a>
        </div>
        <div class="header-center">
            <h1> Employee Dashboard</h1>
            <p>Welcome, <span><?= htmlspecialchars($_SESSION['user_name']) ?></span></p>
        </div>
        <div class="header-right">
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>



    <!-- ADD FORM -->
    <div class="section">
        <div class="section-title">➕ Add New Employee</div>
        <?php if (isset($_GET['added'])): ?>
            <div class="alert-success">✅ Employee added successfully!</div>
        <?php endif; ?>
        <form method="POST" action="add_employee.php">
            <div class="form-grid">
                <input type="text"   name="full_name"  placeholder="Full Name"  required>
                <input type="email"  name="email"      placeholder="Email"      required>
                <input type="text"   name="phone"      placeholder="Phone">
                <select name="department">
                    <option value="Engineering">Engineering</option>
                    <option value="HR">HR</option>
                    <option value="Finance">Finance</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Operations">Operations</option>
                </select>
                <input type="text"   name="position"   placeholder="Position"   required>
                <input type="number" name="salary"     placeholder="Salary"     step="0.01">
            </div>
            <button type="submit" class="btn-add">+ Add Employee</button>
        </form>
    </div>

    <!-- TABLE -->
    <div class="section">
        <div class="section-title">📋 Employee List</div>
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Position</th>
                        <th>Salary</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($employees): ?>
                        <?php foreach ($employees as $emp): ?>
                        <tr>
                            <td style="color:#aaa"><?= $emp['id'] ?></td>
                            <td><strong><?= htmlspecialchars($emp['full_name']) ?></strong></td>
                            <td style="color:#666"><?= htmlspecialchars($emp['email']) ?></td>
                            <td><span class="dept-tag"><?= htmlspecialchars($emp['department']) ?></span></td>
                            <td><?= htmlspecialchars($emp['position']) ?></td>
                            <td><?= $emp['salary'] ? '$'.number_format($emp['salary'],2) : '—' ?></td>
                            <td>
                                <span class="badge <?= $emp['status']==='active' ? 'badge-active' : 'badge-inactive' ?>">
                                    <?= ucfirst($emp['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="home.php?delete=<?= $emp['id'] ?>"
                                   class="delete-btn"
                                   onclick="return confirm('Delete this employee?')">🗑</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="empty">No employees yet — add one above!</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>



</div>
</body>
</html>