<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'employee_system');

function getDBConnection() {
    try {
        // Connect WITHOUT database first to create it if missing
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );

        // Create database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `" . DB_NAME . "`");

        // Create users table if not exists
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin','user') DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");

        // Create employees table if not exists
        $pdo->exec("CREATE TABLE IF NOT EXISTS employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            phone VARCHAR(20),
            department VARCHAR(100),
            position VARCHAR(100),
            salary DECIMAL(10,2),
            hire_date DATE,
            status ENUM('active','inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");

        // Insert sample employees if table is empty
        $count = $pdo->query("SELECT COUNT(*) FROM employees")->fetchColumn();
        if ($count == 0) {
            $pdo->exec("INSERT INTO employees (full_name, email, phone, department, position, salary, hire_date) VALUES
                ('Ahmed Al-Rashid',   'ahmed@example.com',    '+968-1234-5678', 'Engineering', 'Developer',  1500.00, '2023-01-15'),
                ('Sara Al-Balushi',   'sara@example.com',     '+968-2345-6789', 'HR',          'HR Manager', 1800.00, '2022-06-01'),
                ('Mohammed Al-Farsi', 'mohammed@example.com', '+968-3456-7890', 'Finance',     'Accountant', 1400.00, '2023-03-10')
            ");
        }

        return $pdo;

    } catch (PDOException $e) {
        die("
        <div style='font-family:Arial;background:#fff0f0;border-left:5px solid #e74c3c;padding:20px;margin:30px;border-radius:8px;'>
            <h2 style='color:#e74c3c;'>&#10060; Database Connection Failed</h2>
            <p><b>Error:</b> " . $e->getMessage() . "</p>
            <hr style='margin:14px 0'>
            <h3>Fix Steps:</h3>
            <ol style='line-height:2'>
                <li>Make sure <b>WAMP is running</b> (green icon in taskbar)</li>
                <li>If your MySQL password is not empty, open <code>db_config.php</code> and set <code>DB_PASS</code></li>
            </ol>
        </div>");
    }
}
