-- ============================================
-- Employee System Database Setup
-- Run this in phpMyAdmin: Import → select this file
-- ============================================

CREATE DATABASE IF NOT EXISTS employee_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE employee_system;

-- Users table (for login/register)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(100),
    position VARCHAR(100),
    salary DECIMAL(10,2),
    hire_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample employees
INSERT IGNORE INTO employees (full_name, email, phone, department, position, salary, hire_date) VALUES
('Ahmed Al-Rashid',   'ahmed@example.com',    '+968-1234-5678', 'Engineering', 'Developer',   1500.00, '2023-01-15'),
('Sara Al-Balushi',   'sara@example.com',     '+968-2345-6789', 'HR',          'HR Manager',  1800.00, '2022-06-01'),
('Mohammed Al-Farsi', 'mohammed@example.com', '+968-3456-7890', 'Finance',     'Accountant',  1400.00, '2023-03-10');
