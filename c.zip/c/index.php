<?php
session_start();
require_once 'db_config.php';

// If already logged in, go to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit;
}

$pdo     = getDBConnection();
$error   = '';
$success = '';
$mode    = 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'] ?? 'login';

    if ($mode === 'register') {
        $full_name  = trim($_POST['full_name'] ?? '');
        $email      = strtolower(trim($_POST['email'] ?? ''));
        $password   = $_POST['password'] ?? '';
        $department = trim($_POST['department'] ?? '');
        $position   = trim($_POST['position'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
            $mode  = 'register';
        } elseif (strlen($password) < 6) {
            $error = "Password must be at least 6 characters.";
            $mode  = 'register';
        } else {
            try {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$full_name, $email, $hashed]);

                $stmt2 = $pdo->prepare("INSERT INTO employees (full_name, email, department, position, hire_date) VALUES (?, ?, ?, ?, CURDATE())");
                $stmt2->execute([$full_name, $email, $department, $position]);

                $success = "Account created! You can now log in.";
                $mode = 'login';
            } catch (PDOException $e) {
                $error = ($e->getCode() == 23000)
                    ? "An account with this email already exists."
                    : "Something went wrong. Please try again.";
                $mode = 'register';
            }
        }

    } elseif ($mode === 'login') {
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                header('Location: home.php');
                exit;
            } else {
                $error = "Invalid email or password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee System — Login</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: linear-gradient(135deg, #f5f7f5 0%, #c8d9c6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: rgba(255,255,255,0.65);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(24,56,18,0.2);
            border-radius: 24px;
            padding: 36px 32px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 40px rgba(24,56,18,0.1);
        }

        .logo {
            text-align: center;
            margin-bottom: 26px;
        }

        .logo .icon {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, #183812, #3a7a30);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            margin-bottom: 12px;
            box-shadow: 0 4px 14px rgba(24,56,18,0.3);
        }

        .logo h1 {
            font-size: 20px;
            font-weight: 800;
            color: #183812;
            letter-spacing: -0.3px;
        }

        .logo p { color: #777; font-size: 13px; margin-top: 3px; }

        .tabs {
            display: flex;
            background: rgba(24,56,18,0.06);
            border-radius: 12px;
            padding: 4px;
            margin-bottom: 22px;
            gap: 4px;
        }

        .tab {
            flex: 1;
            text-align: center;
            padding: 8px;
            border-radius: 9px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            color: #777;
            border: none;
            background: none;
            transition: all 0.15s;
            font-family: 'DM Sans', sans-serif;
        }

        .tab.active {
            background: linear-gradient(135deg, #183812, #3a7a30);
            color: #fff;
            box-shadow: 0 2px 10px rgba(24,56,18,0.3);
        }

        .form-group { margin-bottom: 13px; }

        label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: #444;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        input, select {
            width: 100%;
            padding: 10px 13px;
            border: 1.5px solid rgba(24,56,18,0.2);
            border-radius: 10px;
            font-size: 14px;
            color: #1a1a1a;
            outline: none;
            transition: border 0.15s;
            background: rgba(255,255,255,0.8);
            font-family: 'DM Sans', sans-serif;
        }

        input:focus, select:focus { border-color: #183812; background: #fff; }
        input.err { border-color: #e53e3e; }

        .divider { height: 1px; background: rgba(24,56,18,0.1); margin: 14px 0; }

        .btn {
            width: 100%;
            padding: 11px;
            background: linear-gradient(135deg, #183812, #3a7a30);
            color: #fff;
            border: none;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 4px;
            transition: opacity 0.15s;
            font-family: 'DM Sans', sans-serif;
            box-shadow: 0 4px 14px rgba(24,56,18,0.3);
        }

        .btn:hover { opacity: 0.88; }

        .alert {
            padding: 10px 13px;
            border-radius: 10px;
            font-size: 13px;
            margin-bottom: 16px;
            font-weight: 500;
        }

        .alert-error   { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }
        .alert-success { background: rgba(24,56,18,0.08); color: #183812; border: 1px solid rgba(24,56,18,0.2); }

        .hidden { display: none; }
    </style>
</head>
<body>
<div class="card">
    <div class="logo">
        <h1>Employee System</h1>
        <p>Manage your team</p>
    </div>

    <div class="tabs">
        <button class="tab <?= $mode === 'login'    ? 'active' : '' ?>" onclick="switchTab('login')">Login</button>
        <button class="tab <?= $mode === 'register' ? 'active' : '' ?>" onclick="switchTab('register')">Register</button>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- LOGIN FORM -->
    <form id="loginForm" method="POST" class="<?= $mode === 'register' ? 'hidden' : '' ?>" novalidate>
        <input type="hidden" name="mode" value="login">
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@example.com" required
                   class="<?= ($mode==='login' && $error) ? 'err' : '' ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="••••••••" required
                   class="<?= ($mode==='login' && $error) ? 'err' : '' ?>">
        </div>
        <button type="submit" class="btn">Login →</button>
    </form>

    <!-- REGISTER FORM -->
    <form id="registerForm" method="POST" class="<?= $mode === 'login' ? 'hidden' : '' ?>" novalidate>
        <input type="hidden" name="mode" value="register">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" placeholder="Your full name" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@example.com" required
                   class="<?= ($mode==='register' && str_contains($error,'email')) ? 'err' : '' ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Min. 6 characters" required minlength="6">
        </div>
        <div class="divider"></div>
        <div class="form-group">
            <label>Department</label>
            <select name="department">
                <option value="Engineering">Engineering</option>
                <option value="HR">HR</option>
                <option value="Finance">Finance</option>
                <option value="Marketing">Marketing</option>
                <option value="Operations">Operations</option>
            </select>
        </div>
        <div class="form-group">
            <label>Position</label>
            <input type="text" name="position" placeholder="e.g. Developer" required>
        </div>
        <button type="submit" class="btn">Create Account →</button>
    </form>
</div>

<script>
function switchTab(tab) {
    document.getElementById('loginForm').classList.toggle('hidden', tab !== 'login');
    document.getElementById('registerForm').classList.toggle('hidden', tab !== 'register');
    document.querySelectorAll('.tab').forEach((t, i) => {
        t.classList.toggle('active', (i===0 && tab==='login') || (i===1 && tab==='register'));
    });
    document.querySelectorAll('input[name=mode]').forEach(el => el.value = tab);
}
</script>
</body>
</html>
